<div id="action-modal" class="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm hidden opacity-0 transition-opacity duration-300">
    <div class="bg-slate-800 w-full max-w-md rounded-3xl border border-slate-700 shadow-2xl overflow-hidden transform scale-95 transition-transform duration-300">
        <div class="p-8 text-center">
            <div id="action-modal-icon-container" class="w-20 h-20 mx-auto bg-blue-500/10 rounded-full flex items-center justify-center mb-6 transition-colors shadow-inner">
                <i id="action-modal-icon" data-lucide="help-circle" class="w-10 h-10 text-blue-400"></i>
            </div>
            <h3 id="action-modal-title" class="text-2xl font-bold text-white mb-2 tracking-tight">Potwierdzenie</h3>
            <p id="action-modal-message" class="text-slate-400 text-sm leading-relaxed mb-6"></p>
            
            <div id="action-modal-input-container" class="hidden mb-6">
                <input type="text" id="action-modal-input" class="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3.5 text-slate-200 outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all font-medium text-center shadow-lg" placeholder="Wpisz nazwę...">
            </div>

            <div class="flex flex-col sm:flex-row gap-3 mt-8">
                <button id="action-modal-cancel" class="sm:flex-1 w-full px-6 py-3.5 bg-slate-700/50 hover:bg-slate-700 text-slate-400 hover:text-slate-200 font-bold rounded-2xl transition-all border border-slate-700/50 order-2 sm:order-1 outline-none">Anuluj</button>
                <button id="action-modal-confirm" class="sm:flex-1 w-full px-6 py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-2xl shadow-lg shadow-blue-600/20 active:scale-95 transition-all order-1 sm:order-2 outline-none">Potwierdź</button>
            </div>
        </div>
    </div>
</div>

<!-- Preview Modal -->
<div id="preview-modal" class="fixed inset-0 z-[120] flex items-center justify-center bg-slate-950/95 backdrop-blur-2xl hidden opacity-0 transition-opacity duration-300">
    <div class="w-full h-full flex flex-col overflow-hidden relative transform scale-95 transition-transform duration-300">

        
        <!-- Floating Close Button -->
        <button onclick="closePreview()" class="absolute top-6 right-6 z-[130] group p-3.5 bg-slate-800/80 hover:bg-red-500/80 text-white rounded-2xl transition-all duration-300 backdrop-blur-md border border-slate-700/50 hover:border-red-500/50 shadow-2xl active:scale-90" title="Zamknij podgląd">
            <i data-lucide="x" class="w-8 h-8 group-hover:rotate-90 transition-transform duration-300"></i>
        </button>
        
        <!-- Content Area (Full Screen) -->
        <div id="preview-content" class="flex-1 overflow-hidden relative flex items-center justify-center">
            <div class="flex items-center justify-center">
                <i data-lucide="loader-2" class="w-12 h-12 text-blue-500 animate-spin"></i>
            </div>
        </div>
        
        <!-- Optimized Footer with Filename -->
        <div class="px-8 py-5 border-t border-slate-800/60 bg-slate-900/90 backdrop-blur-md flex flex-col md:flex-row items-center justify-between gap-4 shrink-0">
            <div class="flex items-center space-x-4 min-w-0">
                <div class="p-2.5 bg-blue-500/10 rounded-xl">
                    <i data-lucide="file-text" class="w-5 h-5 text-blue-400"></i>
                </div>
                <div class="flex flex-col min-w-0">
                    <span id="preview-title" class="text-base font-bold text-white truncate max-w-sm md:max-w-xl">Podgląd pliku</span>
                    <span class="text-[9px] text-slate-500 uppercase font-black tracking-[0.2em] mt-0.5">Sivis Drive Internal Secure Viewer</span>
                </div>
            </div>
            
            <div class="flex items-center gap-6">
                 <div class="hidden lg:flex items-center gap-2 text-[10px] text-slate-500 uppercase font-bold tracking-widest border-r border-slate-800 pr-6">
                    <i data-lucide="shield-check" class="w-4 h-4 text-emerald-500"></i>
                    <span>Tylko do odczytu</span>
                </div>
                <div class="text-[10px] text-slate-400 font-medium">
                    Wowk Digital &copy; <?= date('Y') ?>
                </div>
            </div>
        </div>
    </div>
</div>



